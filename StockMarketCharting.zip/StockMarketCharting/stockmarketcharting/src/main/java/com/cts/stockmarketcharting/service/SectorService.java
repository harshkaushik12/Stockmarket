package com.cts.stockmarketcharting.service;

import com.cts.stockmarketcharting.entity.Sector;

public interface SectorService {
	
	void addSector(Sector sector);

}
