package com.cts.stockmarketcharting.service;

import java.util.List;

import com.cts.stockmarketcharting.entity.IPODetail;


public interface IPOService {

	void save(IPODetail ipo);

	List<IPODetail> findAllIPO();

}
