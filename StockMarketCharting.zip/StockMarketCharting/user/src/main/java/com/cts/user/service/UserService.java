package com.cts.user.service;

import org.springframework.stereotype.Service;

import com.cts.user.entity.User;

public interface UserService {
	public void save(User user);
	public void updateUser(User user,String password);
}
