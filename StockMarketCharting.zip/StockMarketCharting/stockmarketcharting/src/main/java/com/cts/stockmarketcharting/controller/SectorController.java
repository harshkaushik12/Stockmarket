package com.cts.stockmarketcharting.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cts.stockmarketcharting.entity.Sector;
import com.cts.stockmarketcharting.service.SectorService;

@RestController
public class SectorController {
	
	@Autowired
	SectorService sectorService;
	
	ResponseEntity<Void> status;
	
	@RequestMapping(path="/sector", method=RequestMethod.POST)
	public ResponseEntity<Void> addSector(@RequestBody Sector sector)
	{
		sectorService.addSector(sector);
		status=new ResponseEntity<>(HttpStatus.CREATED);
		return status;
	}

}
