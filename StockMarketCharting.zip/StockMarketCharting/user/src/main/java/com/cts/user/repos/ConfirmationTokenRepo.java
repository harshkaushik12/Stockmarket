package com.cts.user.repos;

import org.springframework.data.repository.CrudRepository;

import com.cts.user.entity.ConfirmationToken;

public interface ConfirmationTokenRepo extends CrudRepository<ConfirmationToken, String> {
    ConfirmationToken findByConfirmationToken(String confirmationToken);
}
