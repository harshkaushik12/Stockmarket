package com.cts.stockmarketcharting.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.stockmarketcharting.entity.StockExchange;
import com.cts.stockmarketcharting.repos.StockExchangeRepo;

@Service
public class StockExchangeServiceImpl implements StockExchangeService {

	
	@Autowired
	StockExchangeRepo exchangeRepo;

	@Override
	public StockExchange findExchangeByName(String name) {
	   return exchangeRepo.findStockExchangeByName(name);
	}

	@Override
	public List<StockExchange> findAll() {
		
		return exchangeRepo.findAll();
	}

	@Override
	public void save(StockExchange exchange) {
		exchangeRepo.save(exchange);
		
	}

}
