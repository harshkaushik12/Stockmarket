package com.cts.stockmarketcharting.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "IPODetail")

public class IPODetail {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "IPO_id")
	private int id;
	
	@OneToOne
	@JoinColumn(name="company")
	private Company company;
	
	@Column(name="stock_exchange")
	private String stockExchange;
	
	@NotNull(message = "Price cannot be empty!")
	@Column(name = "IPO_price")
	private long pricePerShare;
	
	@NotNull(message = " No of shares cannot be empty!")
	@Column(name = "IPO_shares")
	private int noOfShares;
	
	@NotNull(message = "Date cannot be empty!")
	@Column(name = "IPO_open_date")
	private Date openDate;
	
	@NotNull(message = "Name cannot be empty!")
	@Column(name = "IPO_remarks")
	private String remarks;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public String getStockExchange() {
		return stockExchange;
	}

	public void setStockExchange(String stockExchange) {
		this.stockExchange = stockExchange;
	}

	public long getPricePerShare() {
		return pricePerShare;
	}

	public void setPricePerShare(long pricePerShare) {
		this.pricePerShare = pricePerShare;
	}

	public int getNoOfShares() {
		return noOfShares;
	}

	public void setNoOfShares(int noOfShares) {
		this.noOfShares = noOfShares;
	}

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public IPODetail(int id, Company company, String stockExchange, long pricePerShare, int noOfShares,
			Date openDate, String remarks) {
		super();
		this.id = id;
		this.company = company;
		this.stockExchange = stockExchange;
		this.pricePerShare = pricePerShare;
		this.noOfShares = noOfShares;
		this.openDate = openDate;
		this.remarks = remarks;
	}

	public IPODetail() {
		super();
		
	}
}
