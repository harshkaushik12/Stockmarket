package com.cts.user.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.cts.user.StockMarketChartingProxy;
import com.cts.user.entity.Company;
import com.cts.user.entity.ConfirmationToken;
import com.cts.user.entity.User;
import com.cts.user.repos.ConfirmationTokenRepo;
import com.cts.user.repos.UserRepo;
import com.cts.user.service.UserService;


@RestController
public class UserController {
	
	
	@Autowired
	UserRepo userRepo;
	
	@Autowired
	UserService userService;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
		
	@Autowired
	StockMarketChartingProxy stockMarketChartingProxy;
	 
	
	@Autowired
    private ConfirmationTokenRepo confirmationTokenRepository;
	
	ResponseEntity<Void> status=null;
	
	@RequestMapping(path="/user", method=RequestMethod.POST)
	public ResponseEntity<Void> addUser(@RequestBody User user){
		
		ArrayList<User> users=new ArrayList<>();
		users.addAll(userRepo.findAll());
		ResponseEntity<Void> status=null;
		for (User objUser : users)  
        { 
            if((objUser.getEmail().contentEquals(user.getEmail())))
            {
            	status = new ResponseEntity<>(HttpStatus.CONFLICT);
            	
            }
            else
            {
            	String encodedPassword = bCryptPasswordEncoder.encode(user.getPassword());
                System.out.println(encodedPassword);
            	user.setPassword(encodedPassword);
        		
            	userService.save(user);
        		status = new ResponseEntity<>(HttpStatus.CREATED);
            	
            }
        } 
		userService.save(user);
		return status;
	}
	

	@RequestMapping(path="/user/{email}/{password}", method=RequestMethod.GET)
	public ResponseEntity<String> signin(@PathVariable String email, @PathVariable String password)
	{
		ArrayList<User> users=new ArrayList<>();
		users.addAll(userRepo.findAll());
		ResponseEntity<String> status=null;
		String encodedPassword = bCryptPasswordEncoder.encode(password);
		for (User user : users) 
		{
			
            if((user.getEmail().contentEquals(email))
            		&& (user.getPassword().contentEquals(encodedPassword)))
            {
            	//status = new ResponseEntity<>("Login Successful",HttpStatus.FOUND);
            
            	
            	if(user.isConfirmed()==true) {
            	status = new ResponseEntity<>("Login Successful",HttpStatus.FOUND);
            	}
            	
            }
            else
            {
            	status = new ResponseEntity<>("Login Unsuccessful",HttpStatus.UNAUTHORIZED);
            	
            }
        } 
		return status;
	}
	
	@RequestMapping(value="/confirm-account", method= {RequestMethod.GET, RequestMethod.POST})
    public ResponseEntity<Void> confirmUserAccount(@RequestParam("token")String confirmationToken)
    {
        ConfirmationToken token = confirmationTokenRepository.findByConfirmationToken(confirmationToken);

        if(token != null)
        {
            User user = userRepo.findByEmailIgnoreCase(token.getUser().getEmail());
            user.setConfirmed(true);
            userService.save(user);
            System.out.println("Confirmed");
            status = new ResponseEntity<>(HttpStatus.OK);
            
        }
        else
        {
        	status = new ResponseEntity<>(HttpStatus.CONFLICT);
        }
        return status;
        
    }
	
	
	
	@RequestMapping(path="/user/{email}/{oldPassword}/{newPassword}", method=RequestMethod.POST)
	public ResponseEntity<Void> updatepassword(@PathVariable String email, @PathVariable String oldPassword,@PathVariable String newPassword)
	{
		ArrayList<User> users=new ArrayList<>();
		users.addAll(userRepo.findAll());
		ResponseEntity<Void> status=null;
		for (User user : users)  
        { 
            if((user.getEmail().contentEquals(email))            		)
            {
            	if(user.getPassword().contentEquals(oldPassword))
            	{
            		userService.updateUser(user,newPassword);
            		status = new ResponseEntity<>(HttpStatus.OK);
            	}
           
            }
            else
            {
            	status = new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
            	
            }
        } 
		return status;
	}
	
	@RequestMapping(path="/stockmarketcharting/companies", method=RequestMethod.GET)
	public List<Company> getCompanies()
	{
		List<Company> result=stockMarketChartingProxy.getCompanies();
		return result;
	}
}
